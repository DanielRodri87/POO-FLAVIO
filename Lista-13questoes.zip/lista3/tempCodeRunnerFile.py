print(lista1)
print(lista2)